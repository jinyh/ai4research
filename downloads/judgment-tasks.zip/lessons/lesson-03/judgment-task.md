# 第 3 课研究任务｜本人问题的检索与判断

## 共同诊断

教师问题：哪些 GPT-2 small IOI 干预会改变答案偏好，效果能否迁移到新模板？种子 arXiv:2211.00593 为给定输入。下面仅列 2026-10-15 历史记录的首轮输入 A，保留请求与元数据，不列后续选中的路径。原始工具完整响应尚未附入本页，元数据不能替代主张全文核验。

接口：`web.run.search_query`。参数：

```json
{"q": "\"indirect object identification\" \"activation patching\" site:arxiv.org"}
```

实际使用的字符串是 `"indirect object identification" "activation patching" site:arxiv.org`。`response_length` 为 `long`。本次可见返回 4 条，按工具显示顺序如下；它们不是已确认纳入的候选表。

| 顺序 | arXiv ID | 返回题名 | 后续审计范围 |
| --- | --- | --- | --- |
| 1 | [2605.22462](https://arxiv.org/abs/2605.22462) | From Correlation to Cause: A Five-Stage Methodology for Feature Analysis in Transformer Language Models | 本课未核主张，pending |
| 2 | [2311.17030](https://arxiv.org/abs/2311.17030) | Is This the Subspace You Are Looking for? An Interpretability Illusion for Subspace Activation Patching | 打开原文，供入口核验 |
| 3 | [2608.03629](https://arxiv.org/abs/2608.03629) | Cross-Layer Interaction under Weight-Space Ablation: A Closed-Form Attention Jacobian Bound and a Test on a Real Pretrained Model | 本课未核主张，pending |
| 4 | [2508.21258](https://arxiv.org/abs/2508.21258) | RelP: Faithful and Efficient Circuit Discovery via Relevance Patching | 本课未核主张，pending |

先独立写当前缺口、下一条路线、实际依据和一个替代选择，再由教师揭示后续动作及核验入口。已读过完整讲义或历史记录者，用本人新问题的首轮返回作相同判断，标明已知信息；不把回忆教师路径当独立检索决策。

无网络时，本页足以完成“种子缺席后下一步”的判断；身份与主张核验使用本人已保存原文。没有原文则记录该项未完成，不能仅凭题名或元数据标为 verified；实际两路检索与 AI 动作仍待补。

## 本人实践

输入来自L2：本人问题、可公开表述、来源与工具授权、网络范围、结果位置。课前在原15分钟阅读预算内读本人种子摘要与相关问题定义；无种子者可从[公开起始池](../../course/source-starter-pool.md)取得给定来源，或选IOI临时备用。

课上向 Agent 交代本人问题、缺口、已有种子、允许来源与预算，实际推进一条路线，根据可见返回选择下一步并记录依据。核对一条关键来源的身份与拟用主张位置；可以使用课前已保存的种子，注明给定身份，不计新发现。未核到原文主张时仍标 pending，保存具体缺项。

课后在既有项目补全预算内，优先补另一条互补路线，完成两条真实来源的身份及各一条拟用主张审计，写原文位置、核验状态、允许主张和本人决定。至少一条已核验候选进入十字段表，pending 保留在线索区。两条均通过或第二路线无新增也可成立；暂停额外数据库和引文分支，避免把旧长实践整体挪课后。专门语义接口不可用时记录原因并选可用路线，不把自然语言输入等同于语义检索。

## 判断时使用的原理

判断下一步时，分别考虑来源覆盖、字段／过滤、排序返回与筛选。只观察到四条返回不能定位唯一漏检原因；两路是本课练习要求，不能证明穷尽。讲义小索引用于解释查准率和召回率，按需查阅，不新增必交输出。

## 产物与交接

统一保存notes/literature-search.md：问题版本、给定种子、实际请求与返回、路线比较与调整依据、两条审计、候选角色与决定、停止条件、未决项及AI使用记录。

在已有来源核验与补全记录中，反查一项纳入决定到原文和发现路径。改变研究对象、数据、场景、论证前提或预算后怎样重判，保留为按需追问或后续实际变化时的回查，不另加一项课上或课后必做。换模型只是条件变化的一例，个人不必改做模型项目。

L4带本人一篇来源及一条关键主张、身份与原文入口、当前允许转述及未决缺口；L4再完成两处证据和第一张完整精读卡。无网络时在存档上练判断，缺失实际检索与AI动作如实登记，在原每课60分钟课外预算内补核。回放不计本人实际运行，不新增正式作业。

## 材料定位

方法依据：[本课方法讲义](https://jinyh.github.io/ai4research/lessons/lesson-03/handout/)。MI 背景状态：[S0](../cases/mi/S0.md)；只取用本任务明确列出的输入。

项目中的历史检索背景与动作关系：[检索材料](https://jinyh.github.io/ai4research/lessons/cases/mi/literature-route/)。真实查询原始维护源仍为本课检索运行记录。
