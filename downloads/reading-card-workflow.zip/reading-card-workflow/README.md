# 阅读卡回放包

源文本、输出和参考标注均为教学构造，不调用模型。
需要 Python 3，无第三方依赖。在解压后的本目录打开终端：

    python3 run.py replay --out runs/demo --fault-once
    python3 run.py replay --out runs/demo
    python3 run.py evaluate --out runs/demo
    python3 run.py access-check --out runs/demo --role executor --resource gold

预期退出码依次为 2、0、0、3。首次受控失败与末步权限拒绝均为预设分支。
每次新复演使用新的输出目录；不要覆盖以前的记录。
阅读卡遗漏 3/8=0.375，自由摘要 4/8=0.500；T02 无改善、T03 负向。
接口角色检查不等于操作系统沙箱。语义由人核验，程序只核查记录与汇总。

运行 python3 test_workflow.py 可验证包的关键行为。
完整说明：https://jinyh.github.io/ai4research/materials/reading-card/
